package com.rain.reggie.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.rain.reggie.entity.DishFlavor;

public interface FlavorService extends IService<DishFlavor> {
}
