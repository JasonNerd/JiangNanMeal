package com.rain.reggie.common;

public class BusinessException extends RuntimeException{
    public BusinessException(String mes){
        super(mes);
    }
}
