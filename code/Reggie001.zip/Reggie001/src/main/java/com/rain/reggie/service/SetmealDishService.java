package com.rain.reggie.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.rain.reggie.entity.SetmealDish;

public interface SetmealDishService extends IService<SetmealDish> {
}
