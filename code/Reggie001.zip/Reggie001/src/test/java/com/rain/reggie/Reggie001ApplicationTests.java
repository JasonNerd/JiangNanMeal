package com.rain.reggie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reggie001ApplicationTests {

    @Test
    void contextLoads() {
    }

}
